# Calculadora Factor IPSC – Joaquim Llorens Edition
